Author: Remko Weijnen (www.remkoweijnen.nl)
Version: 1.0
Date: 12-09-2009

License:
The contents of this file are subject to
the Mozilla Public License Version 1.1 (the "License"); you may
not use this file except in compliance with the License. You may
obtain a copy of the License at
http://www.mozilla.org/MPL/MPL-1.1.html

Software distributed under the License is distributed on an
"AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
implied. See the License for the specific language governing
rights and limitations under the License.

Usage:
Hotkey SHIFT-F2 switches between a Citrix Full Screen desktop and the Local desktop
Hotkey CTRL-F2 exits the Switcher.
